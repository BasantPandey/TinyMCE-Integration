using Microsoft.EntityFrameworkCore;
using customAPI.Models;

namespace customAPI.Data
{
    public class InsightDbContext : DbContext
    {
        public InsightDbContext(DbContextOptions<InsightDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Conversation> Conversations { get; set; }
        public DbSet<Comment> Comments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure User entity
            modelBuilder.Entity<User>()
                .HasKey(u => u.Id);

            modelBuilder.Entity<User>()
                .Property(u => u.Id)
                .IsRequired();

            modelBuilder.Entity<User>()
                .Property(u => u.Name)
                .IsRequired()
                .HasMaxLength(100);

            modelBuilder.Entity<User>()
                .Property(u => u.FullName)
                .IsRequired()
                .HasMaxLength(100);

            modelBuilder.Entity<User>()
                .Property(u => u.Description)
                .HasMaxLength(500);

            modelBuilder.Entity<User>()
                .Property(u => u.Image)
                .HasMaxLength(500);

            // Configure Conversation entity
            modelBuilder.Entity<Conversation>()
                .HasKey(c => c.Uid);

            modelBuilder.Entity<Conversation>()
                .Property(c => c.Uid)
                .IsRequired();

            // Configure Comment entity
            modelBuilder.Entity<Comment>()
                .HasKey(c => c.Uid);

            modelBuilder.Entity<Comment>()
                .Property(c => c.Uid)
                .IsRequired();

            modelBuilder.Entity<Comment>()
                .Property(c => c.Author)
                .IsRequired()
                .HasMaxLength(100);

            modelBuilder.Entity<Comment>()
                .Property(c => c.AuthorName)
                .IsRequired()
                .HasMaxLength(100);

            modelBuilder.Entity<Comment>()
                .Property(c => c.Content)
                .IsRequired();

            // Configure relationships
            modelBuilder.Entity<Comment>()
                .HasOne(c => c.Conversation)
                .WithMany(c => c.Comments)
                .HasForeignKey(c => c.ConversationUid)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
