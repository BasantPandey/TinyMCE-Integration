// TinyMCE integration with the local database
(function() {
  // Use the local database instead of API calls
  const db = window.insightDB;
  
  // Current user information
  let currentUser = null;
  let adminUser = null;
  
  // Initialize by fetching current user and admin user
  const init = async () => {
    try {
      try {
        // Fetch current user (kalebwilson)
        currentUser = await db.getUserById('kalebwilson');
      } catch (error) {
        console.error('Error fetching current user:', error);
        currentUser = null;
      }
      
      try {
        // Fetch admin user (michaelcook)
        adminUser = await db.getUserById('michaelcook');
      } catch (error) {
        console.error('Error fetching admin user:', error);
        adminUser = null;
      }
      
      if (!currentUser && !adminUser) {
        throw new Error('Failed to fetch any users');
      }
      
      return { currentUser, adminUser };
    } catch (error) {
      console.error('Error initializing users:', error);
      return null;
    }
  };
  
  /********************************
   *   Mentions functions    *
   ********************************/
  
  // Fetch users for mentions
  const mentions_fetch = async (query, success) => {
    try {
      const users = await db.searchUsers(query.term);
      success(users);
    } catch (error) {
      console.error('Error fetching mentions:', error);
      success([]);
    }
  };
  
  // Show user profile on hover
  const mentions_menu_hover = async (userInfo, success) => {
    try {
      const userDetail = await db.getUserById(userInfo.id);
      success({ type: 'profile', user: userDetail });
    } catch (error) {
      console.error('Error fetching user for hover:', error);
    }
  };
  
  // Create mention element
  const mentions_menu_complete = (editor, userInfo) => {
    const span = editor.getDoc().createElement('span');
    span.className = 'mymention';
    span.setAttribute('style', 'color: #37F;');
    span.setAttribute('data-mention-id', userInfo.id);
    span.appendChild(editor.getDoc().createTextNode('@' + userInfo.name));
    return span;
  };
  
  // Handle mention selection
  const mentions_select = async (mention, success) => {
    const id = mention.getAttribute('data-mention-id');
    if (id) {
      try {
        const userDetail = await db.getUserById(id);
        success({ type: 'profile', user: userDetail });
      } catch (error) {
        console.error('Error fetching user for selection:', error);
      }
    }
  };
  
  /********************************
   *   Tiny Comments functions    *
   * (must call "done" or "fail") *
   ********************************/
  
  // Create a new conversation
  const tinycomments_create = async (req, done, fail) => {
    try {
      if (req.content === 'fail') {
        fail(new Error('Something has gone wrong...'));
        return;
      }
      
      const result = await db.createConversation(req.content, currentUser.id);
      done({ conversationUid: result.conversationUid });
    } catch (error) {
      console.error('Error creating conversation:', error);
      fail(error);
    }
  };
  
  // Reply to a conversation
  const tinycomments_reply = async (req, done) => {
    try {
      const result = await db.addReply(req.conversationUid, req.content, currentUser.id);
      done({ commentUid: result.commentUid });
    } catch (error) {
      console.error('Error replying to conversation:', error);
      done({ error: error.message });
    }
  };
  
  // Delete a conversation
  const tinycomments_delete = async (req, done) => {
    try {
      const result = await db.deleteConversation(req.conversationUid, currentUser.id);
      done(result); // { canDelete: true/false, reason: '...' }
    } catch (error) {
      console.error('Error deleting conversation:', error);
      done({ canDelete: false, reason: error.message });
    }
  };
  
  // Resolve a conversation
  const tinycomments_resolve = async (req, done) => {
    try {
      const result = await db.resolveConversation(req.conversationUid, currentUser.id);
      done(result); // { canResolve: true/false, reason: '...' }
    } catch (error) {
      console.error('Error resolving conversation:', error);
      done({ canResolve: false, reason: error.message });
    }
  };
  
  // Delete a comment
  const tinycomments_delete_comment = async (req, done) => {
    try {
      const result = await db.deleteComment(req.conversationUid, req.commentUid, currentUser.id);
      done(result); //        { canDelete: true/false, reason: '...' }
    } catch (error) {
      console.error('Error deleting comment:', error);
      done({ canDelete: false, reason: error.message });
    }
  };
  
  // Edit a comment
  const tinycomments_edit_comment = async (req, done) => {
    try {
      const result = await db.editComment(req.conversationUid, req.commentUid, req.content, currentUser.id);
      done(result); // { canEdit: true/false, reason: '...' }
    } catch (error) {
      console.error('Error editing comment:', error);
      done({ canEdit: false, reason: error.message });
    }
  };
  
  // Delete all conversations (same as resolve)
  const tinycomments_delete_all = async (req, done) => {
    try {
      const result = await db.resolveConversation(req.conversationUid, currentUser.id);
      // Convert resolve response to delete response format
      done({ 
        canDelete: result.canResolve, 
        reason: result.reason 
      });
    } catch (error) {
      console.error('Error deleting all conversations:', error);
      done({ canDelete: false, reason: error.message });
    }
  };
  
  // Look up a conversation
  const tinycomments_lookup = async (req, done) => {
    try {
      const conversation = await db.getConversationById(req.conversationUid);
      done({ conversation }); // { conversation: { uid, comments } }
    } catch (error) {
      console.error('Error looking up conversation:', error);
      done({ error: error.message });
    }
  };
  
  // Fetch multiple conversations
  const tinycomments_fetch = async (conversationUids, done) => {
    try {
      const fetchedConversations = {};
      
      // Fetch each conversation individually
      for (const uid of conversationUids) {
        try {
          const conversation = await db.getConversationById(uid);
          if (conversation) {
            fetchedConversations[uid] = conversation;
          }
        } catch (error) {
          console.error(`Error fetching conversation ${uid}:`, error);
          // Continue with other conversations even if one fails
        }
      }
      
      done({ conversations: fetchedConversations });
    } catch (error) {
      console.error('Error fetching conversations:', error);
      done({ conversations: {} });
    }
  };
  
  // Get author info for the current user
  const tinycomments_fetch_author_info = async (done) => {
    try {
      if (!currentUser) {
        // Wait for initialization to complete
        const users = await init();
        if (!users) {
          throw new Error('Failed to initialize users');
        }
      }
      
      if (currentUser) {
        done({
          author: currentUser.id,
          authorName: currentUser.fullName,
          authorAvatar: currentUser.image
        });
      } else {
        // Fallback if currentUser is still null
        done({
          author: 'unknown',
          authorName: 'Unknown User'
        });
      }
    } catch (error) {
      console.error('Error fetching author info:', error);
      done({
        author: 'unknown',
        authorName: 'Unknown User'
      });
    }
  };
  
  // Initialize TinyMCE after users are loaded
  init().then(users => {
    if (!users) {
      console.error('Failed to initialize users');
      return;
    }
    
    console.log('Users initialized, setting up TinyMCE');
    
    // Initialize TinyMCE with our database-connected functions
    if (typeof window !== 'undefined' && window.tinymce) {
      window.tinymce.init({
        selector: 'textarea#comments-callback-with-mentions',
        license_key: 'gpl',
        toolbar: 'addcomment showcomments code | bold italic underline',
        menubar: 'file edit view insert format tools tc help',
        menu: {
          tc: {
            title: 'TinyComments',
            items: 'addcomment showcomments deleteallconversations'
          }
        },
        plugins: [ 'tinycomments', 'mentions', 'help', 'code', 'quickbars', 'link', 'lists', 'image' ],
        quickbars_selection_toolbar: 'alignleft aligncenter alignright | addcomment showcomments',
        quickbars_image_toolbar: 'alignleft aligncenter alignright | rotateleft rotateright | imageoptions',
        tinycomments_mentions_enabled: true,
        sidebar_show: 'showcomments',
      
        mentions_item_type: 'profile',
        mentions_min_chars: 0,
        mentions_selector: '.mymention',
        mentions_fetch,
        mentions_menu_hover,
        mentions_menu_complete,
        mentions_select,
      
        tinycomments_mode: 'callback',
        tinycomments_author: currentUser ? currentUser.id : 'unknown',
        tinycomments_author_name: currentUser ? currentUser.fullName : 'Unknown User',
        tinycomments_avatar: currentUser ? currentUser.image : '',
        tinycomments_create,
        tinycomments_reply,
        tinycomments_delete,
        tinycomments_resolve,
        tinycomments_delete_all,
        tinycomments_lookup,
        tinycomments_delete_comment,
        tinycomments_edit_comment,
        tinycomments_fetch,
        tinycomments_fetch_author_info
      });
    } else {
      console.error('TinyMCE not found. Make sure it is properly loaded.');
    }
  });
})();
