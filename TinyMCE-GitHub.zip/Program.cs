using System.Text.Json.Serialization;
using System;
using System.Collections.Generic;
using customAPI.Models;
using customAPI.Services;
using customAPI.Data;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace customAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateSlimBuilder(args);

            builder.Services.ConfigureHttpJsonOptions(options =>
            {
                options.SerializerOptions.TypeInfoResolverChain.Insert(0, AppJsonSerializerContext.Default);
            });

            // Register services
            builder.Services.AddSingleton<FakerDataGenerator>();
            builder.Services.AddCors(options =>
            {
                options.AddDefaultPolicy(policy =>
                {
                    policy.AllowAnyOrigin()
                          .AllowAnyMethod()
                          .AllowAnyHeader();
                });
            });

            // Configure database context
            builder.Services.AddDbContext<InsightDbContext>(options =>
                options.UseSqlite("Data Source=Insight.db"));

            // Add database initializer service
            builder.Services.AddScoped<DbInitializer>();

            // Add controllers
            builder.Services.AddControllers();

            var app = builder.Build();

            // Enable CORS
            app.UseCors();

            // Enable serving static files
            app.UseStaticFiles();

            // Add controllers
            app.MapControllers();

            // Add a welcome page
            app.MapGet("/", () => Results.Content(
                "<html><body>" +
                "<h1>Welcome to the Custom API</h1>" +
                "<p>Available endpoints:</p>" +
                "<ul>" +
                "<li><a href='/users'>/users</a> - Get all users</li>" +
                "<li><a href='/users/search?q=michael'>/users/search?q=michael</a> - Search for users</li>" +
                "<li><a href='/conversations'>/conversations</a> - Get all conversations</li>" +
                "</ul>" +
                "<p><a href='/index.html'><strong>Try the interactive demo page</strong></a></p>" +
                "</body></html>",
                "text/html"));

            // Get the FakerDataGenerator service
            var fakerDataGenerator = app.Services.GetRequiredService<FakerDataGenerator>();

            // Users API endpoints
            var usersApi = app.MapGroup("/users");

            // Get all users
            usersApi.MapGet("/", async () =>
                await fakerDataGenerator.FetchUsersAsync());

            // Get user by ID
            usersApi.MapGet("/{id}", async (string id) =>
            {
                try
                {
                    return Results.Ok(await fakerDataGenerator.FetchUserAsync(id));
                }
                catch (Exception ex)
                {
                    return Results.NotFound(ex.Message);
                }
            });

            // Search users
            usersApi.MapGet("/search", (string? q) =>
                fakerDataGenerator.SearchUsers(q ?? string.Empty));

            // Conversations API endpoints
            var conversationsApi = app.MapGroup("/conversations");

            // Get all conversations
            conversationsApi.MapGet("/", () =>
                fakerDataGenerator.GetAllConversations());

            // Get conversation by ID
            conversationsApi.MapGet("/{id}", (string id) =>
            {
                var conversation = fakerDataGenerator.GetConversationById(id);
                return conversation != null
                    ? Results.Ok(conversation)
                    : Results.NotFound($"Conversation with ID {id} not found");
            });

            // Create a new conversation
            conversationsApi.MapPost("/", async ([FromBody] CreateConversationRequest request) =>
            {
                try
                {
                    var response = await fakerDataGenerator.CreateConversationAsync(request);
                    return Results.Created($"/conversations/{response.ConversationUid}", response);
                }
                catch (Exception ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            });

            // Add a reply to a conversation
            conversationsApi.MapPost("/{conversationUid}/replies", async ([FromBody] ReplyRequest request) =>
            {
                try
                {
                    var response = await fakerDataGenerator.ReplyToConversationAsync(request);
                    return Results.Ok(response);
                }
                catch (Exception ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            });

            // Resolve a conversation
            conversationsApi.MapPost("/{conversationUid}/resolve", async ([FromBody] ResolveConversationRequest request) =>
            {
                var response = await fakerDataGenerator.ResolveConversationAsync(request);
                return Results.Ok(response);
            });

            // Delete a conversation
            conversationsApi.MapDelete("/{conversationUid}", async (string conversationUid) =>
            {
                var request = new DeleteConversationRequest { ConversationUid = conversationUid };
                var response = await fakerDataGenerator.DeleteConversationAsync(request);
                return Results.Ok(response);
            });

            // Delete a comment
            conversationsApi.MapDelete("/{conversationUid}/comments/{commentUid}", async (string conversationUid, string commentUid) =>
            {
                var request = new DeleteCommentRequest
                {
                    ConversationUid = conversationUid,
                    CommentUid = commentUid
                };
                var response = await fakerDataGenerator.DeleteCommentAsync(request);
                return Results.Ok(response);
            });

            // Edit a comment
            conversationsApi.MapPut("/{conversationUid}/comments/{commentUid}", async ([FromBody] EditCommentRequest request) =>
            {
                var response = await fakerDataGenerator.EditCommentAsync(request);
                return Results.Ok(response);
            });

            // Lookup a conversation
            conversationsApi.MapGet("/{conversationUid}/lookup", async (string conversationUid) =>
            {
                try
                {
                    var request = new LookupRequest { ConversationUid = conversationUid };
                    var response = await fakerDataGenerator.LookupConversationAsync(request);
                    return Results.Ok(response);
                }
                catch (Exception ex)
                {
                    return Results.NotFound(ex.Message);
                }
            });

            // Initialize the database
            using (var scope = app.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                try
                {
                    var dbInitializer = services.GetRequiredService<DbInitializer>();
                    dbInitializer.InitializeAsync().Wait();
                }
                catch (Exception ex)
                {
                    var logger = services.GetRequiredService<ILogger<Program>>();
                    logger.LogError(ex, "An error occurred while seeding the database.");
                }
            }

            app.Run();
        }
    }

    public record Todo(int Id, string? Title, DateOnly? DueBy = null, bool IsComplete = false);

    [JsonSerializable(typeof(Todo[]))]
    [JsonSerializable(typeof(User))]
    [JsonSerializable(typeof(Comment))]
    [JsonSerializable(typeof(Conversation))]
    [JsonSerializable(typeof(List<User>))]
    [JsonSerializable(typeof(List<Conversation>))]
    [JsonSerializable(typeof(CreateConversationRequest))]
    [JsonSerializable(typeof(CreateConversationResponse))]
    [JsonSerializable(typeof(ReplyRequest))]
    [JsonSerializable(typeof(ReplyResponse))]
    [JsonSerializable(typeof(DeleteConversationRequest))]
    [JsonSerializable(typeof(DeleteConversationResponse))]
    [JsonSerializable(typeof(ResolveConversationRequest))]
    [JsonSerializable(typeof(ResolveConversationResponse))]
    [JsonSerializable(typeof(DeleteCommentRequest))]
    [JsonSerializable(typeof(DeleteCommentResponse))]
    [JsonSerializable(typeof(EditCommentRequest))]
    [JsonSerializable(typeof(EditCommentResponse))]
    [JsonSerializable(typeof(LookupRequest))]
    [JsonSerializable(typeof(LookupResponse))]
    internal partial class AppJsonSerializerContext : JsonSerializerContext
    {
        // This is a partial class that will be completed by the JsonSerializer
    }
}
