using System;
using System.Linq;
using System.Threading.Tasks;
using customAPI.Models;
using customAPI.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace customAPI.Data
{
    public class DbInitializer
    {
        private readonly InsightDbContext _context;
        private readonly FakerDataGenerator _fakerDataGenerator;

        public DbInitializer(InsightDbContext context, FakerDataGenerator fakerDataGenerator)
        {
            _context = context;
            _fakerDataGenerator = fakerDataGenerator;
        }

        public async Task InitializeAsync()
        {
            // Create database if it doesn't exist
            await _context.Database.EnsureCreatedAsync();

            // Check if there are any users in the database
            if (!_context.Users.Any())
            {
                await SeedUsersAsync();
            }

            // Check if there are any conversations in the database
            if (!_context.Conversations.Any())
            {
                await SeedConversationsAsync();
            }

            // Save changes to the database
            await _context.SaveChangesAsync();
        }

        private async Task SeedUsersAsync()
        {
            // Get users from the FakerDataGenerator
            var users = await _fakerDataGenerator.FetchUsersAsync();

            // Add users to the database
            foreach (var user in users)
            {
                _context.Users.Add(user);
            }

            await _context.SaveChangesAsync();
        }

        private async Task SeedConversationsAsync()
        {
            // Get conversations from the FakerDataGenerator
            var conversations = _fakerDataGenerator.GetAllConversations();

            // Add conversations to the database
            foreach (var conversation in conversations)
            {
                // Add the conversation
                _context.Conversations.Add(conversation);

                // Add the comments
                foreach (var comment in conversation.Comments)
                {
                    comment.ConversationUid = conversation.Uid;
                    _context.Comments.Add(comment);
                }
            }

            await _context.SaveChangesAsync();
        }
    }
}
