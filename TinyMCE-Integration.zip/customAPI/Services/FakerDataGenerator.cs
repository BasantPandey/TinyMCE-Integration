using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bogus;
using customAPI.Models;

namespace customAPI.Services
{
    /// <summary>
    /// Utility class to generate fake data for testing and development
    /// </summary>
    public class FakerDataGenerator
    {
        private readonly Faker _faker;
        private readonly Dictionary<string, User> _userDb;
        private readonly Dictionary<string, Conversation> _conversationDb;
        private readonly User _currentUser;
        private readonly User _adminUser;
        private readonly int _fakeDelay = 200; // Milliseconds

        /// <summary>
        /// Initializes a new instance of the FakerDataGenerator class
        /// </summary>
        public FakerDataGenerator()
        {
            _faker = new Faker();
            _userDb = new Dictionary<string, User>();
            _conversationDb = new Dictionary<string, Conversation>();

            // Initialize predefined users
            _adminUser = new User
            {
                Id = "michaelcook",
                Name = "Michael Cook",
                FullName = "Michael Cook",
                Description = "Product Owner",
                Image = "../_images/avatars/michaelcook.png"
            };

            _currentUser = new User
            {
                Id = "kalebwilson",
                Name = "Kaleb Wilson",
                FullName = "Kaleb Wilson",
                Description = "Marketing Director",
                Image = "../_images/avatars/kalebwilson.png"
            };

            // Add predefined users to the database
            _userDb.Add(_adminUser.Id, _adminUser);
            _userDb.Add(_currentUser.Id, _currentUser);

            // Generate additional users
            GenerateUsers(200);

            // Generate sample conversations
            GenerateSampleConversations();
        }

        /// <summary>
        /// Gets all users in the database
        /// </summary>
        public List<User> GetAllUsers() => _userDb.Values.ToList();

        /// <summary>
        /// Gets a user by their ID
        /// </summary>
        public User GetUserById(string id) => _userDb.ContainsKey(id) ? _userDb[id] : null;

        /// <summary>
        /// Gets all conversations in the database
        /// </summary>
        public List<Conversation> GetAllConversations() => _conversationDb.Values.ToList();

        /// <summary>
        /// Gets a conversation by its ID
        /// </summary>
        public Conversation GetConversationById(string id) => _conversationDb.ContainsKey(id) ? _conversationDb[id] : null;

        /// <summary>
        /// Gets the current user
        /// </summary>
        public User CurrentUser => _currentUser;

        /// <summary>
        /// Gets the admin user
        /// </summary>
        public User AdminUser => _adminUser;

        /// <summary>
        /// Generates a specified number of fake users
        /// </summary>
        private void GenerateUsers(int count)
        {
            var images = new List<string> { _adminUser.Image, _currentUser.Image };

            // Generate additional random avatar URLs
            for (int i = 0; i < count; i++)
            {
                images.Add(_faker.Internet.Avatar());
            }

            // Create fake users
            for (int i = 0; i < count; i++)
            {
                var firstName = _faker.Name.FirstName();
                var lastName = _faker.Name.LastName();
                var fullName = $"{firstName} {lastName}";
                var id = fullName.ToLower().Replace(" ", "");

                if (!_userDb.ContainsKey(id))
                {
                    var user = new User
                    {
                        Id = id,
                        Name = fullName,
                        FullName = fullName,
                        Description = _faker.Name.JobTitle(),
                        Image = images[_faker.Random.Int(0, images.Count - 1)]
                    };

                    _userDb.Add(id, user);
                }
            }
        }

        /// <summary>
        /// Generates sample conversations with comments
        /// </summary>
        private void GenerateSampleConversations()
        {
            var now = DateTime.UtcNow;
            var yesterday = now.AddDays(-1);
            var anHourAgo = now.AddHours(-1);

            // Create first conversation
            var conversation1 = new Conversation
            {
                Uid = "mce-conversation_19679600221621399703915",
                Comments = new List<Comment>
                {
                    new Comment
                    {
                        Uid = "mce-conversation_19679600221621399703915",
                        Author = _currentUser.Id,
                        AuthorName = _currentUser.FullName,
                        AuthorAvatar = _currentUser.Image,
                        Content = $"What do you think about this? @{_adminUser.Id}?",
                        CreatedAt = yesterday,
                        ModifiedAt = yesterday
                    },
                    new Comment
                    {
                        Uid = "mce-conversation_19679600221621399703917",
                        Author = _adminUser.Id,
                        AuthorName = _adminUser.FullName,
                        AuthorAvatar = _adminUser.Image,
                        Content = $"I think this is a great idea @{_currentUser.Id}!",
                        CreatedAt = anHourAgo,
                        ModifiedAt = anHourAgo
                    }
                }
            };

            // Create second conversation
            var conversation2 = new Conversation
            {
                Uid = "mce-conversation_420304606321716900864126",
                Comments = new List<Comment>
                {
                    new Comment
                    {
                        Uid = "mce-conversation_420304606321716900864126",
                        Author = _adminUser.Id,
                        AuthorName = _adminUser.FullName,
                        AuthorAvatar = _adminUser.Image,
                        Content = $"@{_currentUser.Id} Please revise this sentence, exclamation points are unprofessional!",
                        CreatedAt = yesterday,
                        ModifiedAt = anHourAgo
                    }
                }
            };

            _conversationDb.Add(conversation1.Uid, conversation1);
            _conversationDb.Add(conversation2.Uid, conversation2);
        }

        /// <summary>
        /// Creates a new conversation with an initial comment
        /// </summary>
        public Conversation CreateConversation(string content)
        {
            var uid = $"annotation-{GenerateRandomString()}";
            var now = DateTime.UtcNow;

            var conversation = new Conversation
            {
                Uid = uid,
                Comments = new List<Comment>
                {
                    new Comment
                    {
                        Uid = uid,
                        Author = _currentUser.Id,
                        AuthorName = _currentUser.FullName,
                        AuthorAvatar = _currentUser.Image,
                        Content = content,
                        CreatedAt = now,
                        ModifiedAt = now
                    }
                }
            };

            _conversationDb.Add(uid, conversation);
            return conversation;
        }

        /// <summary>
        /// Adds a reply to an existing conversation
        /// </summary>
        public Comment AddReply(string conversationUid, string content)
        {
            if (!_conversationDb.ContainsKey(conversationUid))
                return null;

            var replyUid = $"annotation-{GenerateRandomString()}";
            var now = DateTime.UtcNow;

            var comment = new Comment
            {
                Uid = replyUid,
                Author = _currentUser.Id,
                AuthorName = _currentUser.FullName,
                AuthorAvatar = _currentUser.Image,
                Content = content,
                CreatedAt = now,
                ModifiedAt = now
            };

            _conversationDb[conversationUid].Comments.Add(comment);
            return comment;
        }

        /// <summary>
        /// Generates a random string for use as an ID
        /// </summary>
        private string GenerateRandomString()
        {
            return Guid.NewGuid().ToString("N").Substring(0, 12);
        }

        /// <summary>
        /// Simulates fetching all users from the server with a delay
        /// </summary>
        public async Task<List<User>> FetchUsersAsync()
        {
            // Simulate server delay
            await Task.Delay(_fakeDelay);
            return _userDb.Values.ToList();
        }

        /// <summary>
        /// Simulates fetching a specific user from the server with a delay
        /// </summary>
        public async Task<User> FetchUserAsync(string id)
        {
            // Simulate server delay
            await Task.Delay(_fakeDelay);

            if (_userDb.ContainsKey(id))
            {
                return _userDb[id];
            }

            throw new Exception($"unknown user id \"{id}\"");
        }

        /// <summary>
        /// Searches for users whose name or ID contains the specified query
        /// </summary>
        public List<User> SearchUsers(string query)
        {
            if (string.IsNullOrEmpty(query))
            {
                return _userDb.Values.ToList();
            }

            return _userDb.Values
                .Where(user =>
                    user.Name.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    user.Id.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0)
                .ToList();
        }

        /// <summary>
        /// Creates a new conversation asynchronously
        /// </summary>
        public async Task<CreateConversationResponse> CreateConversationAsync(CreateConversationRequest request)
        {
            // Simulate server delay
            await Task.Delay(_fakeDelay);

            if (request.Content == "fail")
            {
                throw new Exception("Something has gone wrong...");
            }

            var uid = $"annotation-{GenerateRandomString()}";
            var conversation = new Conversation
            {
                Uid = uid,
                Comments = new List<Comment>
                {
                    new Comment
                    {
                        Uid = uid,
                        Author = _currentUser.Id,
                        AuthorName = _currentUser.FullName,
                        AuthorAvatar = _currentUser.Image,
                        Content = request.Content,
                        CreatedAt = request.CreatedAt,
                        ModifiedAt = request.CreatedAt
                    }
                }
            };

            _conversationDb.Add(uid, conversation);

            return new CreateConversationResponse
            {
                ConversationUid = uid
            };
        }

        /// <summary>
        /// Adds a reply to an existing conversation asynchronously
        /// </summary>
        public async Task<ReplyResponse> ReplyToConversationAsync(ReplyRequest request)
        {
            // Simulate server delay
            await Task.Delay(_fakeDelay);

            if (!_conversationDb.ContainsKey(request.ConversationUid))
            {
                throw new Exception($"Conversation with ID {request.ConversationUid} not found");
            }

            var replyUid = $"annotation-{GenerateRandomString()}";
            var comment = new Comment
            {
                Uid = replyUid,
                Author = _currentUser.Id,
                AuthorName = _currentUser.FullName,
                AuthorAvatar = _currentUser.Image,
                Content = request.Content,
                CreatedAt = request.CreatedAt,
                ModifiedAt = request.CreatedAt
            };

            _conversationDb[request.ConversationUid].Comments.Add(comment);

            return new ReplyResponse
            {
                CommentUid = replyUid
            };
        }

        /// <summary>
        /// Deletes a conversation asynchronously
        /// </summary>
        public async Task<DeleteConversationResponse> DeleteConversationAsync(DeleteConversationRequest request)
        {
            // Simulate server delay
            await Task.Delay(_fakeDelay);

            if (!_conversationDb.ContainsKey(request.ConversationUid))
            {
                return new DeleteConversationResponse
                {
                    CanDelete = false,
                    Reason = "Conversation not found"
                };
            }

            // Check if current user is admin (replace with your own logic)
            if (_currentUser.Id == _adminUser.Id)
            {
                _conversationDb.Remove(request.ConversationUid);
                return new DeleteConversationResponse
                {
                    CanDelete = true
                };
            }

            return new DeleteConversationResponse
            {
                CanDelete = false,
                Reason = "Must be admin user"
            };
        }

        /// <summary>
        /// Resolves a conversation asynchronously
        /// </summary>
        public async Task<ResolveConversationResponse> ResolveConversationAsync(ResolveConversationRequest request)
        {
            // Simulate server delay
            await Task.Delay(_fakeDelay);

            if (!_conversationDb.ContainsKey(request.ConversationUid))
            {
                return new ResolveConversationResponse
                {
                    CanResolve = false,
                    Reason = "Conversation not found"
                };
            }

            var conversation = _conversationDb[request.ConversationUid];
            if (conversation.Comments.Count == 0)
            {
                return new ResolveConversationResponse
                {
                    CanResolve = false,
                    Reason = "Conversation has no comments"
                };
            }

            // Check if current user is the author of the first comment
            if (_currentUser.Id == conversation.Comments[0].Author)
            {
                _conversationDb.Remove(request.ConversationUid);
                return new ResolveConversationResponse
                {
                    CanResolve = true
                };
            }

            return new ResolveConversationResponse
            {
                CanResolve = false,
                Reason = "Must be conversation author"
            };
        }

        /// <summary>
        /// Deletes a comment asynchronously
        /// </summary>
        public async Task<DeleteCommentResponse> DeleteCommentAsync(DeleteCommentRequest request)
        {
            // Simulate server delay
            await Task.Delay(_fakeDelay);

            if (!_conversationDb.ContainsKey(request.ConversationUid))
            {
                return new DeleteCommentResponse
                {
                    CanDelete = false,
                    Reason = "Conversation not found"
                };
            }

            var oldComments = _conversationDb[request.ConversationUid].Comments;
            string reason = "Comment not found";

            var newComments = oldComments.Where(comment =>
            {
                if (comment.Uid == request.CommentUid)
                {
                    // Found the comment to delete
                    if (_currentUser.Id == comment.Author)
                    {
                        // User can delete their own comments
                        return false; // Remove the comment
                    }
                    else
                    {
                        reason = "Not authorized to delete this comment";
                    }
                }
                return true; // Keep the comment
            }).ToList();

            if (newComments.Count == oldComments.Count)
            {
                return new DeleteCommentResponse
                {
                    CanDelete = false,
                    Reason = reason
                };
            }

            _conversationDb[request.ConversationUid].Comments = newComments;
            return new DeleteCommentResponse
            {
                CanDelete = true
            };
        }

        /// <summary>
        /// Edits a comment asynchronously
        /// </summary>
        public async Task<EditCommentResponse> EditCommentAsync(EditCommentRequest request)
        {
            // Simulate server delay
            await Task.Delay(_fakeDelay);

            if (!_conversationDb.ContainsKey(request.ConversationUid))
            {
                return new EditCommentResponse
                {
                    CanEdit = false,
                    Reason = "Conversation not found"
                };
            }

            var oldComments = _conversationDb[request.ConversationUid].Comments;
            string reason = "Comment not found";
            bool canEdit = false;

            var newComments = oldComments.Select(comment =>
            {
                if (comment.Uid == request.CommentUid)
                {
                    // Found the comment to edit
                    if (_currentUser.Id == comment.Author)
                    {
                        // User can edit their own comments
                        canEdit = true;
                        return new Comment
                        {
                            Uid = comment.Uid,
                            Author = comment.Author,
                            AuthorName = comment.AuthorName,
                            AuthorAvatar = comment.AuthorAvatar,
                            Content = request.Content,
                            CreatedAt = comment.CreatedAt,
                            ModifiedAt = DateTime.UtcNow
                        };
                    }
                    else
                    {
                        reason = "Not authorized to edit this comment";
                    }
                }
                return comment; // Keep the comment unchanged
            }).ToList();

            if (canEdit)
            {
                _conversationDb[request.ConversationUid].Comments = newComments;
                return new EditCommentResponse
                {
                    CanEdit = true
                };
            }

            return new EditCommentResponse
            {
                CanEdit = false,
                Reason = reason
            };
        }

        /// <summary>
        /// Looks up a conversation asynchronously
        /// </summary>
        public async Task<LookupResponse> LookupConversationAsync(LookupRequest request)
        {
            // Simulate server delay
            await Task.Delay(_fakeDelay);

            if (!_conversationDb.ContainsKey(request.ConversationUid))
            {
                throw new Exception($"Conversation with ID {request.ConversationUid} not found");
            }

            return new LookupResponse
            {
                Conversation = _conversationDb[request.ConversationUid]
            };
        }
    }
}
