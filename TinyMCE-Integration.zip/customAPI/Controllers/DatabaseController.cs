using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using customAPI.Data;
using customAPI.Models;

namespace customAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DatabaseController : ControllerBase
    {
        private readonly InsightDbContext _context;

        public DatabaseController(InsightDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<string>> GetDatabaseInfo()
        {
            var userCount = await _context.Users.CountAsync();
            var conversationCount = await _context.Conversations.CountAsync();
            var commentCount = await _context.Comments.CountAsync();

            return Ok(new
            {
                DatabaseName = "Insight",
                UserCount = userCount,
                ConversationCount = conversationCount,
                CommentCount = commentCount,
                Status = "Connected"
            });
        }

        [HttpGet("users")]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            return await _context.Users.ToListAsync();
        }

        [HttpGet("conversations")]
        public async Task<ActionResult<IEnumerable<Conversation>>> GetConversations()
        {
            return await _context.Conversations
                .Include(c => c.Comments)
                .ToListAsync();
        }
    }
}
