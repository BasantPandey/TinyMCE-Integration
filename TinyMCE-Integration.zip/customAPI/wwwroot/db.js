// Simple in-memory database for storing TinyMCE data
const insightDB = {
  users: [],
  conversations: [],
  comments: []
};

// Initialize the database with some sample data
(function initializeDB() {
  // Sample users
  insightDB.users = [
    {
      id: 'kalebwilson',
      name: 'Kaleb Wilson',
      fullName: 'Kaleb Wilson',
      description: 'Marketing Director',
      image: '../_images/avatars/kalebwilson.png'
    },
    {
      id: 'michaelcook',
      name: 'Michael Cook',
      fullName: 'Michael Cook',
      description: 'Product Owner',
      image: '../_images/avatars/michaelcook.png'
    },
    {
      id: 'sarahjohnson',
      name: 'Sarah Johnson',
      fullName: 'Sarah Johnson',
      description: 'UX Designer',
      image: 'https://randomuser.me/api/portraits/women/42.jpg'
    },
    {
      id: 'robertsmith',
      name: 'Robert Smith',
      fullName: 'Robert Smith',
      description: 'Software Engineer',
      image: 'https://randomuser.me/api/portraits/men/32.jpg'
    }
  ];

  // Sample conversations
  const now = new Date();
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  const hourAgo = new Date(now);
  hourAgo.setHours(hourAgo.getHours() - 1);

  // Create first conversation
  const conversation1 = {
    uid: 'mce-conversation_19679600221621399703915',
    comments: [
      {
        uid: 'mce-conversation_19679600221621399703915',
        author: 'kalebwilson',
        authorName: 'Kaleb Wilson',
        authorAvatar: '../_images/avatars/kalebwilson.png',
        content: `What do you think about this? @michaelcook?`,
        createdAt: yesterday.toISOString(),
        modifiedAt: yesterday.toISOString(),
        conversationUid: 'mce-conversation_19679600221621399703915'
      },
      {
        uid: 'mce-conversation_19679600221621399703917',
        author: 'michaelcook',
        authorName: 'Michael Cook',
        authorAvatar: '../_images/avatars/michaelcook.png',
        content: `I think this is a great idea @kalebwilson!`,
        createdAt: hourAgo.toISOString(),
        modifiedAt: hourAgo.toISOString(),
        conversationUid: 'mce-conversation_19679600221621399703915'
      }
    ]
  };

  // Create second conversation
  const conversation2 = {
    uid: 'mce-conversation_420304606321716900864126',
    comments: [
      {
        uid: 'mce-conversation_420304606321716900864126',
        author: 'michaelcook',
        authorName: 'Michael Cook',
        authorAvatar: '../_images/avatars/michaelcook.png',
        content: `@kalebwilson Please revise this sentence, exclamation points are unprofessional!`,
        createdAt: yesterday.toISOString(),
        modifiedAt: hourAgo.toISOString(),
        conversationUid: 'mce-conversation_420304606321716900864126'
      }
    ]
  };

  insightDB.conversations.push(conversation1);
  insightDB.conversations.push(conversation2);

  // Extract comments for easier access
  conversation1.comments.forEach(comment => {
    insightDB.comments.push(comment);
  });
  
  conversation2.comments.forEach(comment => {
    insightDB.comments.push(comment);
  });

  console.log('Database initialized with sample data');
})();

// Database operations
const db = {
  // User operations
  getUsers: () => {
    return Promise.resolve([...insightDB.users]);
  },
  
  getUserById: (id) => {
    const user = insightDB.users.find(u => u.id === id);
    return Promise.resolve(user || null);
  },
  
  searchUsers: (query) => {
    if (!query) {
      return Promise.resolve([...insightDB.users]);
    }
    
    const lowerQuery = query.toLowerCase();
    const results = insightDB.users.filter(user => 
      user.name.toLowerCase().includes(lowerQuery) || 
      user.id.toLowerCase().includes(lowerQuery)
    );
    
    return Promise.resolve(results);
  },
  
  // Conversation operations
  getConversations: () => {
    return Promise.resolve([...insightDB.conversations]);
  },
  
  getConversationById: (id) => {
    const conversation = insightDB.conversations.find(c => c.uid === id);
    return Promise.resolve(conversation || null);
  },
  
  createConversation: (content, author) => {
    const uid = `annotation-${generateRandomString()}`;
    const now = new Date().toISOString();
    
    const user = insightDB.users.find(u => u.id === author);
    if (!user) {
      return Promise.reject(new Error(`User with ID ${author} not found`));
    }
    
    const comment = {
      uid,
      author: user.id,
      authorName: user.fullName,
      authorAvatar: user.image,
      content,
      createdAt: now,
      modifiedAt: now,
      conversationUid: uid
    };
    
    const conversation = {
      uid,
      comments: [comment]
    };
    
    insightDB.conversations.push(conversation);
    insightDB.comments.push(comment);
    
    return Promise.resolve({ conversationUid: uid });
  },
  
  addReply: (conversationUid, content, author) => {
    const conversation = insightDB.conversations.find(c => c.uid === conversationUid);
    if (!conversation) {
      return Promise.reject(new Error(`Conversation with ID ${conversationUid} not found`));
    }
    
    const user = insightDB.users.find(u => u.id === author);
    if (!user) {
      return Promise.reject(new Error(`User with ID ${author} not found`));
    }
    
    const uid = `annotation-${generateRandomString()}`;
    const now = new Date().toISOString();
    
    const comment = {
      uid,
      author: user.id,
      authorName: user.fullName,
      authorAvatar: user.image,
      content,
      createdAt: now,
      modifiedAt: now,
      conversationUid
    };
    
    conversation.comments.push(comment);
    insightDB.comments.push(comment);
    
    return Promise.resolve({ commentUid: uid });
  },
  
  deleteConversation: (conversationUid, author) => {
    const conversationIndex = insightDB.conversations.findIndex(c => c.uid === conversationUid);
    if (conversationIndex === -1) {
      return Promise.resolve({ 
        canDelete: false, 
        reason: 'Conversation not found' 
      });
    }
    
    // Check if user is admin (for this demo, michaelcook is admin)
    if (author === 'michaelcook') {
      // Remove all comments for this conversation
      insightDB.comments = insightDB.comments.filter(c => c.conversationUid !== conversationUid);
      // Remove the conversation
      insightDB.conversations.splice(conversationIndex, 1);
      
      return Promise.resolve({ canDelete: true });
    }
    
    return Promise.resolve({ 
      canDelete: false, 
      reason: 'Must be admin user' 
    });
  },
  
  resolveConversation: (conversationUid, author) => {
    const conversation = insightDB.conversations.find(c => c.uid === conversationUid);
    if (!conversation) {
      return Promise.resolve({ 
        canResolve: false, 
        reason: 'Conversation not found' 
      });
    }
    
    if (conversation.comments.length === 0) {
      return Promise.resolve({ 
        canResolve: false, 
        reason: 'Conversation has no comments' 
      });
    }
    
    // Check if user is the author of the first comment
    if (conversation.comments[0].author === author) {
      // Remove all comments for this conversation
      insightDB.comments = insightDB.comments.filter(c => c.conversationUid !== conversationUid);
      // Remove the conversation
      const index = insightDB.conversations.findIndex(c => c.uid === conversationUid);
      insightDB.conversations.splice(index, 1);
      
      return Promise.resolve({ canResolve: true });
    }
    
    return Promise.resolve({ 
      canResolve: false, 
      reason: 'Must be conversation author' 
    });
  },
  
  deleteComment: (conversationUid, commentUid, author) => {
    const conversation = insightDB.conversations.find(c => c.uid === conversationUid);
    if (!conversation) {
      return Promise.resolve({ 
        canDelete: false, 
        reason: 'Conversation not found' 
      });
    }
    
    const commentIndex = conversation.comments.findIndex(c => c.uid === commentUid);
    if (commentIndex === -1) {
      return Promise.resolve({ 
        canDelete: false, 
        reason: 'Comment not found' 
      });
    }
    
    const comment = conversation.comments[commentIndex];
    
    // Check if user is the author of the comment
    if (comment.author === author) {
      // Remove the comment from the conversation
      conversation.comments.splice(commentIndex, 1);
      // Remove the comment from the comments array
      const globalCommentIndex = insightDB.comments.findIndex(c => c.uid === commentUid);
      if (globalCommentIndex !== -1) {
        insightDB.comments.splice(globalCommentIndex, 1);
      }
      
      return Promise.resolve({ canDelete: true });
    }
    
    return Promise.resolve({ 
      canDelete: false, 
      reason: 'Not authorized to delete this comment' 
    });
  },
  
  editComment: (conversationUid, commentUid, content, author) => {
    const conversation = insightDB.conversations.find(c => c.uid === conversationUid);
    if (!conversation) {
      return Promise.resolve({ 
        canEdit: false, 
        reason: 'Conversation not found' 
      });
    }
    
    const comment = conversation.comments.find(c => c.uid === commentUid);
    if (!comment) {
      return Promise.resolve({ 
        canEdit: false, 
        reason: 'Comment not found' 
      });
    }
    
    // Check if user is the author of the comment
    if (comment.author === author) {
      // Update the comment
      comment.content = content;
      comment.modifiedAt = new Date().toISOString();
      
      // Also update in the global comments array
      const globalComment = insightDB.comments.find(c => c.uid === commentUid);
      if (globalComment) {
        globalComment.content = content;
        globalComment.modifiedAt = comment.modifiedAt;
      }
      
      return Promise.resolve({ canEdit: true });
    }
    
    return Promise.resolve({ 
      canEdit: false, 
      reason: 'Not authorized to edit this comment' 
    });
  }
};

// Helper function to generate a random string for IDs
function generateRandomString() {
  return Math.random().toString(36).substring(2, 14);
}

// Export the database
window.insightDB = db;
