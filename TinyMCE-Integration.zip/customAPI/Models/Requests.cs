using System;
using customAPI.Models;

namespace customAPI.Models
{
    /// <summary>
    /// Request to create a new conversation
    /// </summary>
    public class CreateConversationRequest
    {
        /// <summary>
        /// The content of the initial comment
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// The date and time when the comment was created
        /// </summary>
        public DateTime CreatedAt { get; set; }
    }

    /// <summary>
    /// Response from creating a new conversation
    /// </summary>
    public class CreateConversationResponse
    {
        /// <summary>
        /// The unique identifier of the created conversation
        /// </summary>
        public string ConversationUid { get; set; }
    }

    /// <summary>
    /// Request to add a reply to an existing conversation
    /// </summary>
    public class ReplyRequest
    {
        /// <summary>
        /// The unique identifier of the conversation to reply to
        /// </summary>
        public string ConversationUid { get; set; }

        /// <summary>
        /// The content of the reply
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// The date and time when the reply was created
        /// </summary>
        public DateTime CreatedAt { get; set; }
    }

    /// <summary>
    /// Response from adding a reply to a conversation
    /// </summary>
    public class ReplyResponse
    {
        /// <summary>
        /// The unique identifier of the created comment
        /// </summary>
        public string CommentUid { get; set; }
    }

    /// <summary>
    /// Request to delete a conversation
    /// </summary>
    public class DeleteConversationRequest
    {
        /// <summary>
        /// The unique identifier of the conversation to delete
        /// </summary>
        public string ConversationUid { get; set; }
    }

    /// <summary>
    /// Response from deleting a conversation
    /// </summary>
    public class DeleteConversationResponse
    {
        /// <summary>
        /// Whether the conversation could be deleted
        /// </summary>
        public bool CanDelete { get; set; }

        /// <summary>
        /// The reason why the conversation could not be deleted, if applicable
        /// </summary>
        public string Reason { get; set; }
    }

    /// <summary>
    /// Request to resolve a conversation
    /// </summary>
    public class ResolveConversationRequest
    {
        /// <summary>
        /// The unique identifier of the conversation to resolve
        /// </summary>
        public string ConversationUid { get; set; }
    }

    /// <summary>
    /// Response from resolving a conversation
    /// </summary>
    public class ResolveConversationResponse
    {
        /// <summary>
        /// Whether the conversation could be resolved
        /// </summary>
        public bool CanResolve { get; set; }

        /// <summary>
        /// The reason why the conversation could not be resolved, if applicable
        /// </summary>
        public string Reason { get; set; }
    }

    /// <summary>
    /// Request to delete a comment
    /// </summary>
    public class DeleteCommentRequest
    {
        /// <summary>
        /// The unique identifier of the conversation containing the comment
        /// </summary>
        public string ConversationUid { get; set; }

        /// <summary>
        /// The unique identifier of the comment to delete
        /// </summary>
        public string CommentUid { get; set; }
    }

    /// <summary>
    /// Response from deleting a comment
    /// </summary>
    public class DeleteCommentResponse
    {
        /// <summary>
        /// Whether the comment could be deleted
        /// </summary>
        public bool CanDelete { get; set; }

        /// <summary>
        /// The reason why the comment could not be deleted, if applicable
        /// </summary>
        public string Reason { get; set; }
    }

    /// <summary>
    /// Request to edit a comment
    /// </summary>
    public class EditCommentRequest
    {
        /// <summary>
        /// The unique identifier of the conversation containing the comment
        /// </summary>
        public string ConversationUid { get; set; }

        /// <summary>
        /// The unique identifier of the comment to edit
        /// </summary>
        public string CommentUid { get; set; }

        /// <summary>
        /// The new content of the comment
        /// </summary>
        public string Content { get; set; }
    }

    /// <summary>
    /// Response from editing a comment
    /// </summary>
    public class EditCommentResponse
    {
        /// <summary>
        /// Whether the comment could be edited
        /// </summary>
        public bool CanEdit { get; set; }

        /// <summary>
        /// The reason why the comment could not be edited, if applicable
        /// </summary>
        public string Reason { get; set; }
    }

    /// <summary>
    /// Request to look up a conversation
    /// </summary>
    public class LookupRequest
    {
        /// <summary>
        /// The unique identifier of the conversation to look up
        /// </summary>
        public string ConversationUid { get; set; }
    }

    /// <summary>
    /// Response from looking up a conversation
    /// </summary>
    public class LookupResponse
    {
        /// <summary>
        /// The conversation that was looked up
        /// </summary>
        public Conversation Conversation { get; set; }
    }
}
