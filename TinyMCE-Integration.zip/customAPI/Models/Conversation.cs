using System;
using System.Collections.Generic;

namespace customAPI.Models
{
    /// <summary>
    /// Represents a conversation containing multiple comments
    /// </summary>
    public class Conversation
    {
        /// <summary>
        /// The unique identifier for the conversation
        /// </summary>
        public string Uid { get; set; }

        /// <summary>
        /// The list of comments in this conversation
        /// </summary>
        public List<Comment> Comments { get; set; } = new List<Comment>();
    }
}
