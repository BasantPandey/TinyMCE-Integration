// Type definitions for TinyMCE
declare namespace TinyMCE {
  interface Editor {
    getDoc(): Document;
  }
}

declare interface Window {
  tinymce: {
    init(settings: any): void;
  };
}
