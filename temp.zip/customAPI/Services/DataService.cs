using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using customAPI.Models;

namespace customAPI.Services
{
    /// <summary>
    /// Service for interacting with the API
    /// </summary>
    public class DataService
    {
        private readonly ApiClient _apiClient;
        private User _currentUser;
        private User _adminUser;

        /// <summary>
        /// Initializes a new instance of the DataService class
        /// </summary>
        /// <param name="apiUrl">The base URL of the API</param>
        public DataService(string apiUrl)
        {
            _apiClient = new ApiClient(apiUrl);
        }

        /// <summary>
        /// Initializes the service by loading the current and admin users
        /// </summary>
        public async Task InitializeAsync()
        {
            // Load the current user (assuming we know the ID)
            _currentUser = await _apiClient.GetUserAsync("kalebwilson");

            // Load the admin user (assuming we know the ID)
            _adminUser = await _apiClient.GetUserAsync("michaelcook");
        }

        /// <summary>
        /// Gets the current user
        /// </summary>
        public User CurrentUser => _currentUser;

        /// <summary>
        /// Gets the admin user
        /// </summary>
        public User AdminUser => _adminUser;

        /// <summary>
        /// Fetches all users from the API
        /// </summary>
        public Task<List<User>> FetchUsersAsync()
        {
            return _apiClient.GetUsersAsync();
        }

        /// <summary>
        /// Fetches a specific user by ID from the API
        /// </summary>
        public Task<User> FetchUserAsync(string id)
        {
            return _apiClient.GetUserAsync(id);
        }

        /// <summary>
        /// Searches for users by query
        /// </summary>
        public Task<List<User>> SearchUsersAsync(string query)
        {
            return _apiClient.SearchUsersAsync(query);
        }

        /// <summary>
        /// Gets all conversations from the API
        /// </summary>
        public Task<List<Conversation>> GetAllConversationsAsync()
        {
            return _apiClient.GetConversationsAsync();
        }

        /// <summary>
        /// Gets a conversation by ID from the API
        /// </summary>
        public Task<Conversation> GetConversationByIdAsync(string id)
        {
            return _apiClient.GetConversationAsync(id);
        }

        /// <summary>
        /// Creates a new conversation
        /// </summary>
        public Task<CreateConversationResponse> CreateConversationAsync(CreateConversationRequest request)
        {
            return _apiClient.CreateConversationAsync(request);
        }

        /// <summary>
        /// Adds a reply to a conversation
        /// </summary>
        public Task<ReplyResponse> ReplyToConversationAsync(ReplyRequest request)
        {
            return _apiClient.ReplyToConversationAsync(request);
        }

        /// <summary>
        /// Deletes a conversation
        /// </summary>
        public Task<DeleteConversationResponse> DeleteConversationAsync(DeleteConversationRequest request)
        {
            return _apiClient.DeleteConversationAsync(request);
        }

        /// <summary>
        /// Resolves a conversation
        /// </summary>
        public Task<ResolveConversationResponse> ResolveConversationAsync(ResolveConversationRequest request)
        {
            return _apiClient.ResolveConversationAsync(request);
        }

        /// <summary>
        /// Deletes a comment
        /// </summary>
        public Task<DeleteCommentResponse> DeleteCommentAsync(DeleteCommentRequest request)
        {
            return _apiClient.DeleteCommentAsync(request);
        }

        /// <summary>
        /// Edits a comment
        /// </summary>
        public Task<EditCommentResponse> EditCommentAsync(EditCommentRequest request)
        {
            return _apiClient.EditCommentAsync(request);
        }

        /// <summary>
        /// Generates a random string for use as an ID
        /// </summary>
        public string GenerateRandomString()
        {
            return Guid.NewGuid().ToString("N").Substring(0, 12);
        }
    }
}
