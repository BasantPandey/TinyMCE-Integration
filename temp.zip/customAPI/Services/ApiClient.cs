using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using customAPI.Models;

namespace customAPI.Services
{
    /// <summary>
    /// Client for interacting with the API
    /// </summary>
    public class ApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _baseUrl;
        private readonly JsonSerializerOptions _jsonOptions;

        /// <summary>
        /// Initializes a new instance of the ApiClient class
        /// </summary>
        /// <param name="baseUrl">The base URL of the API</param>
        public ApiClient(string baseUrl)
        {
            _baseUrl = baseUrl;
            _httpClient = new HttpClient();
            _jsonOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
        }

        /// <summary>
        /// Gets all users from the API
        /// </summary>
        public async Task<List<User>> GetUsersAsync()
        {
            var response = await _httpClient.GetAsync($"{_baseUrl}/users");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<User>>(_jsonOptions);
        }

        /// <summary>
        /// Gets a user by ID from the API
        /// </summary>
        public async Task<User> GetUserAsync(string id)
        {
            var response = await _httpClient.GetAsync($"{_baseUrl}/users/{id}");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<User>(_jsonOptions);
        }

        /// <summary>
        /// Gets all conversations from the API
        /// </summary>
        public async Task<List<Conversation>> GetConversationsAsync()
        {
            var response = await _httpClient.GetAsync($"{_baseUrl}/conversations");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<Conversation>>(_jsonOptions);
        }

        /// <summary>
        /// Gets a conversation by ID from the API
        /// </summary>
        public async Task<Conversation> GetConversationAsync(string id)
        {
            var response = await _httpClient.GetAsync($"{_baseUrl}/conversations/{id}");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Conversation>(_jsonOptions);
        }

        /// <summary>
        /// Creates a new conversation
        /// </summary>
        public async Task<CreateConversationResponse> CreateConversationAsync(CreateConversationRequest request)
        {
            var content = new StringContent(JsonSerializer.Serialize(request, _jsonOptions), Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync($"{_baseUrl}/conversations", content);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<CreateConversationResponse>(_jsonOptions);
        }

        /// <summary>
        /// Adds a reply to a conversation
        /// </summary>
        public async Task<ReplyResponse> ReplyToConversationAsync(ReplyRequest request)
        {
            var content = new StringContent(JsonSerializer.Serialize(request, _jsonOptions), Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync($"{_baseUrl}/conversations/{request.ConversationUid}/replies", content);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<ReplyResponse>(_jsonOptions);
        }

        /// <summary>
        /// Deletes a conversation
        /// </summary>
        public async Task<DeleteConversationResponse> DeleteConversationAsync(DeleteConversationRequest request)
        {
            var response = await _httpClient.DeleteAsync($"{_baseUrl}/conversations/{request.ConversationUid}");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<DeleteConversationResponse>(_jsonOptions);
        }

        /// <summary>
        /// Resolves a conversation
        /// </summary>
        public async Task<ResolveConversationResponse> ResolveConversationAsync(ResolveConversationRequest request)
        {
            var content = new StringContent(JsonSerializer.Serialize(request, _jsonOptions), Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync($"{_baseUrl}/conversations/{request.ConversationUid}/resolve", content);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<ResolveConversationResponse>(_jsonOptions);
        }

        /// <summary>
        /// Deletes a comment
        /// </summary>
        public async Task<DeleteCommentResponse> DeleteCommentAsync(DeleteCommentRequest request)
        {
            var response = await _httpClient.DeleteAsync($"{_baseUrl}/conversations/{request.ConversationUid}/comments/{request.CommentUid}");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<DeleteCommentResponse>(_jsonOptions);
        }

        /// <summary>
        /// Edits a comment
        /// </summary>
        public async Task<EditCommentResponse> EditCommentAsync(EditCommentRequest request)
        {
            var content = new StringContent(JsonSerializer.Serialize(request, _jsonOptions), Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync($"{_baseUrl}/conversations/{request.ConversationUid}/comments/{request.CommentUid}", content);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<EditCommentResponse>(_jsonOptions);
        }

        /// <summary>
        /// Searches for users by query
        /// </summary>
        public async Task<List<User>> SearchUsersAsync(string query)
        {
            var response = await _httpClient.GetAsync($"{_baseUrl}/users/search?q={Uri.EscapeDataString(query)}");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<User>>(_jsonOptions);
        }
    }
}
