using System;
using System.Text.Json.Serialization;

namespace customAPI.Models
{
    /// <summary>
    /// Represents a comment in a conversation
    /// </summary>
    public class Comment
    {
        /// <summary>
        /// The unique identifier for the comment
        /// </summary>
        public string Uid { get; set; }

        /// <summary>
        /// The ID of the author who created the comment
        /// </summary>
        public string Author { get; set; }

        /// <summary>
        /// The display name of the author
        /// </summary>
        public string AuthorName { get; set; }

        /// <summary>
        /// The path to the author's avatar image
        /// </summary>
        public string AuthorAvatar { get; set; }

        /// <summary>
        /// The content of the comment
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// The date and time when the comment was created
        /// </summary>
        public DateTime CreatedAt { get; set; }

        /// <summary>
        /// The date and time when the comment was last modified
        /// </summary>
        public DateTime ModifiedAt { get; set; }

        /// <summary>
        /// The ID of the conversation this comment belongs to
        /// </summary>
        public string ConversationUid { get; set; }

        /// <summary>
        /// The conversation this comment belongs to
        /// </summary>
        [JsonIgnore]
        public Conversation Conversation { get; set; }
    }
}
