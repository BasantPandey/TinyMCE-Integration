using System;

namespace customAPI.Models
{
    /// <summary>
    /// Represents a user in the system
    /// </summary>
    public class User
    {
        /// <summary>
        /// The unique identifier for the user
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// The display name of the user
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The full name of the user
        /// </summary>
        public string FullName { get; set; }

        /// <summary>
        /// A description of the user, typically their job title
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// The path to the user's avatar image
        /// </summary>
        public string Image { get; set; }
    }
}
